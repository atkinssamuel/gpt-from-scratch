import pandas as pd
import numpy as np
import pkg_resources
import pickle
import pandas as pd
import pickle
import os

from sklearn.datasets import make_classification
from sklearn import datasets
from sklearn.preprocessing import MinMaxScaler

_data_dir = "../data/"


class DataBank:
    def __init__(self) -> None:
        self.names = ["adult", "iris", "sklearn"]

        for name in self.names:
            if not os.path.exists(local_file(_data_dir + name + ".data")):
                wrangle_tabular()
                break

        with open(local_file(_data_dir + "adult.data"), "rb") as file:
            self.adult = pickle.load(file)

        with open(local_file(_data_dir + "iris.data"), "rb") as file:
            self.iris = pickle.load(file)

        with open(local_file(_data_dir + "sklearn.data"), "rb") as file:
            self.sklearn = pickle.load(file)

        self.dfs = [self.adult, self.iris, self.sklearn]

        self.info = self.compile_db_info()

    def compile_db_info(self):
        df_info_list = []
        for df in self.dfs:
            df_info_list.append(df.info())
        info = pd.DataFrame(df_info_list)
        info["names"] = self.names
        return info.set_index("names")


class Data:
    def __init__(
        self,
        df: pd.DataFrame,
        class_col: str,
    ) -> None:
        self.X = df.drop(columns=[class_col])
        self.columns = self.X.columns
        self.X = self.X.to_numpy()
        np.random.shuffle(self.X)
        self.y = df.loc[:, class_col].to_numpy()

        self.ohcs = []
        self.continuous = []
        for i in range(len(self.columns)):
            if len(np.unique(self.X[:, i])) == 2:
                self.ohcs.append(i)
            else:
                self.continuous.append(i)

    def min_max_scale(self):
        scaler = MinMaxScaler()
        self.X[:, self.continuous] = scaler.fit_transform(self.X[:, self.continuous])

    def info(self):
        return {
            "n_rows": self.X.shape[0],
            "n_cols": self.X.shape[1],
            "n_one_hot": len(self.ohcs),
            "n_continuous": len(self.continuous),
            "n_classes": len(np.unique(self.y)),
        }

    def to_csv(self, filename: str, concat: bool = False):
        if concat:
            concat_data = np.hstack((self.X, self.y.reshape(-1, 1)))
            concat_cols = list(self.columns) + ["score"]

            df = pd.DataFrame(concat_data, columns=concat_cols)
            df.to_csv(filename, index=False)

        else:
            X_df = pd.DataFrame(self.X, columns=list(self.columns))
            X_df.to_csv("X_" + filename, index=False)

            y_df = pd.DataFrame(self.y.reshape(-1, 1), columns=["score"])
            y_df.to_csv("y_" + filename, index=False)


def local_file(name: str):
    return pkg_resources.resource_filename(__name__, "../" + name)


def wrangle_tabular():
    """
    Wrangling the adult dataset
    """
    adult_df = pd.read_csv(local_file(_data_dir + "adult.csv"), skipinitialspace=True)
    adult_df = adult_df.drop(
        columns=["education-num", "fnlwgt", "capital-gain", "capital-loss"]
    )
    class_label_mapping = {"<=50K": 0, ">50K": 1}
    adult_df["income"] = adult_df["income"].map(class_label_mapping)

    country_to_region = {
        "United-States": "North America",
        "Canada": "North America",
        "Mexico": "North America",
        "Cuba": "North America",
        "Jamaica": "North America",
        "Puerto-Rico": "North America",
        "Honduras": "North America",
        "Outlying-US(Guam-USVI-etc)": "North America",
        "Guatemala": "North America",
        "El-Salvador": "North America",
        "Dominican-Republic": "North America",
        "Trinadad&Tobago": "North America",
        "Haiti": "North America",
        "Holand-Netherlands": "Europe",
        "England": "Europe",
        "Germany": "Europe",
        "Italy": "Europe",
        "Poland": "Europe",
        "France": "Europe",
        "Portugal": "Europe",
        "Scotland": "Europe",
        "Greece": "Europe",
        "Ireland": "Europe",
        "Yugoslavia": "Europe",
        "Hungary": "Europe",
        "India": "Asia",
        "Philippines": "Asia",
        "China": "Asia",
        "Japan": "Asia",
        "Cambodia": "Asia",
        "Thailand": "Asia",
        "Laos": "Asia",
        "Taiwan": "Asia",
        "Vietnam": "Asia",
        "Hong": "Asia",
        "Columbia": "South America",
        "Ecuador": "South America",
        "Peru": "South America",
        "Nicaragua": "South America",
    }

    adult_df["native-country"] = adult_df["native-country"].map(country_to_region)

    # Replace countries that don't map to a region with 'Other'
    adult_df["native-country"].fillna("Other", inplace=True)

    adult_df = pd.get_dummies(
        adult_df,
        columns=[
            "workclass",
            "education",
            "marital-status",
            "occupation",
            "relationship",
            "race",
            "sex",
            "native-country",
        ],
    )

    adult_data = Data(adult_df, "income")

    with open(local_file(_data_dir + "adult.data"), "wb") as file:
        pickle.dump(adult_data, file)

    """
    Wrangling the Iris dataset
    """
    # Load the Iris dataset
    iris = datasets.load_iris()
    iris_df = pd.DataFrame(data=iris.data, columns=iris.feature_names)
    iris_df["target"] = iris.target

    iris_data = Data(iris_df, "target")

    with open(local_file(_data_dir + "iris.data"), "wb") as file:
        pickle.dump(iris_data, file)

    """
    Wrangling the sklearn dataset
    """
    # Generate synthetic dataset with 5 classes
    X, y = make_classification(
        n_samples=1000,
        n_features=15,
        n_informative=5,  # Increase the number of informative features
        n_classes=5,  # Specify the number of classes
        n_clusters_per_class=1,
        random_state=42,
    )

    # Create a pandas DataFrame with named columns
    column_names = [f"Feature_{i}" for i in range(X.shape[1])]
    sklearn_df = pd.DataFrame(X, columns=column_names)
    sklearn_df["target"] = y  # Add a column for the target variable (class labels)

    sklearn_data = Data(sklearn_df, "target")

    with open(local_file(_data_dir + "sklearn.data"), "wb") as file:
        pickle.dump(sklearn_data, file)
