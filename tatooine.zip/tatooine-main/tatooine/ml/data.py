from abc import ABC, abstractmethod


class ModelData(ABC):
    """
    A data container which requires that certain methods be implemented in order for
    the class to be compatible with the various PyTorch modelling functionalities
    in the tatooine repository.
    """

    def __init__(self) -> None:
        return

    @abstractmethod
    def get_batch(self):
        raise NotImplementedError
