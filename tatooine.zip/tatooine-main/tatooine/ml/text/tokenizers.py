class CharacterTokenizer:
    def __init__(self, vocabulary: str):
        """
        A CharacterTokenizer is able to encode strings at the character level by mapping
        each character in the vocabulary to a unique integer value.

        Parameters
        ----------
        vocabulary : str
            All of the characters in the vocabulary. All of the values in this input
            string need to be unique and sorted.
        """
        if sorted(list(set(vocabulary))) != vocabulary:
            raise Exception(
                "Vocabulary input to 'CharacterTokenizer' is not a sorted string of unique characters."
            )

        self.stoi, self.itos = dict(), dict()

        for i, ch in enumerate(vocabulary):
            self.stoi[ch] = i
            self.itos[i] = ch

    def encode(self, s: str):
        return [self.stoi[ch] for ch in s]

    def decode(self, l: list):
        return "".join([self.itos[i] for i in l])
