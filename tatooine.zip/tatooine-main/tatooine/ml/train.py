import torch.nn as nn
import torch
import datetime

from .data import ModelData


@torch.no_grad()
def estimate_loss(model: nn.Module, data: ModelData, n_eval_iters: int):
    out = {}
    model.eval()
    for split in ["train", "valid"]:
        losses = torch.zeros(n_eval_iters)
        for k in range(n_eval_iters):
            X, y = data.get_batch(split=split)
            _, loss = model(X, y)
            losses[k] = loss.item()
        out[split] = losses.mean()
    model.train()
    return out


def train_model(
    model: nn.Module,
    data: ModelData,
    optimizer: torch.optim.Optimizer,
    n_updates=10000,
    checkpoint_iter=100,
    n_eval_iters=100,
    model_dir="models/",
    model_name="optimal.model",
):
    min_val_loss = None

    for i in range(n_updates):
        xb, yb = data.get_batch()

        _, loss = model(xb, yb)

        if checkpoint_iter is not None and i % checkpoint_iter == 0:
            out = estimate_loss(model, data, n_eval_iters)

            print(
                f"step {i}: train loss = {out['train']:.4f}, valid loss = {out['valid']:.4f}"
            )

            if min_val_loss is None or out["valid"] < min_val_loss:
                min_val_loss = out["valid"]
                torch.save(model.state_dict(), model_dir + model_name)

        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
