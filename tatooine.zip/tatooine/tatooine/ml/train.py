import torch.nn as nn
import torch
import time
import numpy as np

from tatooine.plotter import Plot
from torch.utils.data import DataLoader
from torch.nn.parallel import DistributedDataParallel as DDP
from typing import Union


@torch.no_grad()
def estimate_loss(
    model: nn.Module,
    train_loader: DataLoader,
    valid_loader: DataLoader,
    n_eval_iters: int,
):
    out = {}
    model.eval()

    train_batcher = iter(train_loader)
    valid_batcher = iter(valid_loader)

    for split in ["train", "valid"]:
        losses = torch.zeros(n_eval_iters)
        for k in range(n_eval_iters):
            xb, yb = next(train_batcher if split == "train" else valid_batcher)
            _, loss = model(xb, yb)
            losses[k] = loss.mean()
        out[split] = losses.mean()

    model.train()
    return out


def train_model(
    model: nn.Module,
    train_loader: DataLoader,
    valid_loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: Union[int, str] = "cpu",
    n_updates=10000,
    checkpoint_iter=100,
    n_eval_iters=100,
    result_dir="results/",
    model_dir="models/",
    model_name="optimal.model",
):
    min_val_loss = None

    train_losses = []
    valid_losses = []

    start_time = time.time()
    last_time = time.time()

    model = model.to(device)
    if device != "cpu":
        model = DDP(model, device_ids=[device])

    train_batcher = iter(train_loader)
    for i in range(n_updates):
        if (
            checkpoint_iter is not None
            and i % checkpoint_iter == 0
            and (device == "cpu" or device == 0)
        ):
            out = estimate_loss(model, train_loader, valid_loader, n_eval_iters)

            train_losses.append(out["train"])
            valid_losses.append(out["valid"])

            print(
                f"{('GPU-' + str(device)) if device != 'cpu' else 'CPU'} - step {i}: "
                f"train loss = {out['train']:.4f}, valid loss = {out['valid']:.4f} "
                f"- total time = {(time.time() - start_time):.1f}, "
                f"{checkpoint_iter} iter time = {(time.time() - last_time):.1f}"
            )

            if min_val_loss is None or out["valid"] < min_val_loss:
                min_val_loss = out["valid"]
                torch.save(
                    model.state_dict()
                    if device == "cpu"
                    else model.module.state_dict(),
                    model_dir + model_name,
                )

            last_time = time.time()

        xb, yb = next(train_batcher)
        _, loss = model(xb, yb)
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()

    if device == "cpu" or device == 0:
        Plot.lines(
            np.arange(len(train_losses)) * checkpoint_iter,
            [train_losses, valid_losses],
            title="Training and Validation Loss Curves",
            xlabel="Update Iteration",
            ylabel="Loss",
            labels=["Training Loss", "Validation Loss"],
            path=result_dir + "loss.png",
        )
