import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

from typing import List, Union
from enum import Enum


def _get_length(
    L: Union[List, np.ndarray],
    error_msg: str = "Input argument to '_get_length' is not a List or an np.ndarray.",
) -> int:
    if isinstance(L, List):
        return len(L)
    elif isinstance(L, np.ndarray):
        return L.shape[0]
    else:
        raise Exception(error_msg)


def _handle_plot(title: str, xlabel: str, ylabel: str, grid: bool, path: str):
    plt.grid(grid)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.savefig(path)


class Palette(Enum):
    Tableau = 1


class Plot:
    @staticmethod
    def line(
        *args,
        path: str = "default.png",
        title: str = "",
        xlabel: str = "x",
        ylabel: str = "y",
        color: str = "magenta",
        alpha: float = 0.7,
        label: str = None,
        grid: bool = True,
    ):
        plt.clf()
        if len(args) > 2:
            raise Exception("More than 2 arguments passed to 'Plot.line' function")
        elif len(args) == 2:
            plt.plot(args[0], args[1], label=label, color=color, alpha=alpha)
        else:
            y_len = _get_length(args[0])
            plt.plot(np.arange(y_len), args[0], label=label, alpha=alpha)
        if label is not None:
            plt.legend()

        _handle_plot(title, xlabel, ylabel, grid, path)

    @staticmethod
    def lines(
        x: Union[np.ndarray, List[np.array]],
        ys: List[Union[np.array, List]],
        xlabel: str = "x",
        ylabel: str = "y",
        labels: List[str] = None,
        colors: Union[List[str], Palette] = Palette.Tableau,
        alphas: List[float] = None,
        path: str = "default.png",
        title: str = "",
        grid: bool = True,
    ):
        _default_alpha = 0.7
        _length_error = (
            lambda arg: f"Length of '{arg}' argument in 'Plot.lines' is not the same as the length of the 'ys' argument."
        )

        for list_arg, label in zip(
            [labels, colors, alphas], ["labels", "colors", "alphas"]
        ):
            if isinstance(list_arg, List) and len(list_arg) != len(ys):
                raise Exception(_length_error(label))

        if isinstance(colors, Palette):
            if colors == Palette.Tableau:
                tableau_colors = list(mcolors.TABLEAU_COLORS)[::-1]
                colors = [
                    tableau_colors[i % len(tableau_colors)] for i in range(len(ys))
                ]
            else:
                colors = None

        _shape_mistmatch_error = "Shapes of data in 'x' and 'ys' arguments to 'Plot.lines' function do not match."

        plt.clf()

        for i in range(len(ys)):
            _x = x if isinstance(x, np.ndarray) else x[i]
            if _get_length(_x) != _get_length(ys[i]):
                raise Exception(_shape_mistmatch_error)
            plt.plot(
                _x,
                ys[i],
                label=labels[i] if isinstance(labels, List) else None,
                alpha=alphas[i] if isinstance(alphas, List) else _default_alpha,
                color=colors[i] if isinstance(colors, List) else None,
            )

        if labels is not None:
            plt.legend()

        _handle_plot(title, xlabel, ylabel, grid, path)
